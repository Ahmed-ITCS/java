public class stringpalindrome {
    static boolean palindromee(String s,int size,int si)
    {
        if(s.charAt(size) == s.charAt(si))
        {
            if(si == s.length()-1 )
            {
                return true;
            }
            return palindromee(s, size-1, si+1);
        }
        else{
            return false;

        }
    }
    public static void main(String[] args)
    {
        String s = "moom";
        System.out.println("is it palindrome ? :  "+palindromee(s,s.length()-1, 0));
    }
}
