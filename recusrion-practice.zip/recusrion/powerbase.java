

/*class solution {
    static int power(int n , int p)
    {
        if(p ==1)
        {
            return n;
        }
        else{
            return power(n , p-1) * n;
        }

    }
    public static void main(String[] args)
    {
        System.out.print(power(5,3));
    }
}
*/