/*class solution {
    
    static int sumofn(int n)
    {
        if(n==0)
        {
            return n;
        }
        else{
            return sumofn(n-1) + n;
        }
    }
    public static void main(String[] args)
    {
        System.out.print(sumofn(5));
    }
}*/