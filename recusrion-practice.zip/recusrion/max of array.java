/*class solution{
    static int getmax(int[] arr , int max, int size)
    {
        if(size != 0)
        {
            if(arr[size] > max)
            {
                max = arr[size];
            }
            return getmax(arr , max , size-1);
        }
        else{
            return max;
        }
    }
    public static void main(String[] args)
    {
        int size = 5;
        int[] arr = {65,213,12,125,999};
        arr = new int[5+1];
        arr[0] = 65;
        arr[1] = 213;
        arr[2] = 12;
        arr[3] = 125;
        arr[4] = 999;
        int max = 0;
        max = getmax(arr,max,size);
        System.out.println("max number is "+max);

    }
}*/